package stock;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class StockController {

    // Returns the number of products in stock for a given productNumber (hard coded)
    @GetMapping("/stock/{productNumber}")
    public Integer getStock(@PathVariable("productNumber") String productNumber) {
        return 25;
    }
}
