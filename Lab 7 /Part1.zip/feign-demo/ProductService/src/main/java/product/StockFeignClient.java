package product;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

// Feign generates the HTTP client that calls the StockService
@FeignClient(name = "StockService", url = "${stockservice.url}")
public interface StockFeignClient {

    @GetMapping("/stock/{productNumber}")
    Integer getStock(@PathVariable("productNumber") String productNumber);
}
