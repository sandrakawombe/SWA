package product;

public class Product {
    private String productNumber;
    private String name;
    private Integer numberOnStock;

    public Product() {
    }

    public Product(String productNumber, String name, Integer numberOnStock) {
        this.productNumber = productNumber;
        this.name = name;
        this.numberOnStock = numberOnStock;
    }

    public String getProductNumber() { return productNumber; }
    public void setProductNumber(String productNumber) { this.productNumber = productNumber; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Integer getNumberOnStock() { return numberOnStock; }
    public void setNumberOnStock(Integer numberOnStock) { this.numberOnStock = numberOnStock; }
}
