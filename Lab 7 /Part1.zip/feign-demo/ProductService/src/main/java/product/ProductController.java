package product;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController {

    private final StockFeignClient stockClient;

    public ProductController(StockFeignClient stockClient) {
        this.stockClient = stockClient;
    }

    @GetMapping("/product/{productNumber}")
    public Product getProduct(@PathVariable("productNumber") String productNumber) {
        Integer numberOnStock = stockClient.getStock(productNumber); // call StockService via Feign
        return new Product(productNumber, "Product " + productNumber, numberOnStock);
    }
}
