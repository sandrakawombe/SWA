# Feign demo: ProductService -> StockService

Two Spring Boot 3.3 projects (Java 17+, Maven).

| Service        | Port | Endpoint                 | Returns                                   |
|----------------|------|--------------------------|-------------------------------------------|
| StockService   | 8900 | GET /stock/{productNumber}   | number on stock (hard coded: 25)          |
| ProductService | 8901 | GET /product/{productNumber} | Product (productNumber, name, numberOnStock) |

ProductService calls StockService through the Feign client `StockFeignClient`
(enabled with `@EnableFeignClients`, uses `spring-cloud-starter-openfeign`).

## Run

Start StockService first, then ProductService (two terminals):

    cd StockService
    mvn spring-boot:run

    cd ProductService
    mvn spring-boot:run

Or open each folder as a project in IntelliJ / Eclipse and run the `*Application` class.

## Test

    http://localhost:8900/stock/1    ->  25
    http://localhost:8901/product/1  ->  {"productNumber":"1","name":"Product 1","numberOnStock":25}
