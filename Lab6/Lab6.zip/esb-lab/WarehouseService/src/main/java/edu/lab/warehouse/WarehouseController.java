package edu.lab.warehouse;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WarehouseController {

    @PostMapping("/orders")
    public ResponseEntity<String> receiveOrder(@RequestBody Order order) {
        System.out.println("WarehouseService received: " + order);
        return ResponseEntity.ok("WarehouseService handled " + order.getOrderNumber());
    }
}
