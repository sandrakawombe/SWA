package edu.lab.nextdayshipping;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NextDayShippingController {

    @PostMapping("/orders")
    public ResponseEntity<String> receiveOrder(@RequestBody Order order) {
        System.out.println("NextDayShippingService received: " + order);
        return ResponseEntity.ok("NextDayShippingService handled " + order.getOrderNumber());
    }
}
