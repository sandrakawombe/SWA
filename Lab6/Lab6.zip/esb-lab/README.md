# ESB Lab – Spring Boot + Spring Integration

Six standalone Spring Boot 3.3.5 projects (Java 17+). Each folder has its own complete pom.xml and can be opened and run on its own; the root pom.xml only exists to build them all at once.

| Module                        | Port | Role                                   |
|-------------------------------|------|----------------------------------------|
| EnterpriseServiceBus          | 8080 | ESB: channels, routers, activators     |
| WarehouseService              | 8081 | receives every order                   |
| NormalShippingService         | 8082 | domestic orders of 175 dollars or less |
| NextDayShippingService        | 8083 | domestic orders above 175 dollars      |
| InternationalShippingService  | 8084 | all international orders               |
| OrderService                  | –    | client, sends test orders to the ESB   |

## Flow (part b, default)

```
OrderService --REST--> OrderController (ESB, 8080)
  -> warehousechannel -> WarehouseActivator --REST--> WarehouseService (8081)
  -> shippingchannel  -> OrderTypeRouter
       international -> internationalshippingchannel -> InternationalShippingActivator -> 8084
       domestic      -> domesticshippingchannel -> OrderAmountRouter
                          amount > 175  -> nextdayshippingchannel -> NextDayShippingActivator -> 8083
                          amount <= 175 -> normalshippingchannel  -> NormalShippingActivator  -> 8082
```

## Part a

Same ESB, but `shippingchannel` goes straight into `OrderAmountRouter` (one router).
Config: `EnterpriseServiceBus/src/main/resources/integration-part-a.xml`.
Start the ESB with the program argument `--esb.config=integration-part-a.xml`.

## How to run

1. Open the root folder (`esb-lab`) in IntelliJ as a Maven project, or open each service folder as its own project
   (or run `mvn clean install` in the root folder).
2. Start, in any order:
   EnterpriseServiceBus, WarehouseService, NormalShippingService,
   NextDayShippingService, InternationalShippingService.
3. Run OrderService last.

From the command line, start each one in its own terminal:

```
mvn -pl EnterpriseServiceBus spring-boot:run
mvn -pl WarehouseService spring-boot:run
mvn -pl NormalShippingService spring-boot:run
mvn -pl NextDayShippingService spring-boot:run
mvn -pl InternationalShippingService spring-boot:run
mvn -pl OrderService spring-boot:run
```

Part a from the command line:

```
mvn -pl EnterpriseServiceBus spring-boot:run -Dspring-boot.run.arguments=--esb.config=integration-part-a.xml
```

## Expected output (part b)

| Order | Amount | Type          | Printed by                   |
|-------|--------|---------------|------------------------------|
| O-1   | 100.00 | domestic      | NormalShippingService        |
| O-2   | 250.00 | domestic      | NextDayShippingService       |
| O-3   | 175.00 | domestic      | NormalShippingService        |
| O-4   | 175.01 | domestic      | NextDayShippingService       |
| O-5   | 80.00  | international | InternationalShippingService |
| O-6   | 900.00 | international | InternationalShippingService |

Every order is also printed by WarehouseService.
An order of exactly 175 dollars is not "more than 175", so it goes to normal shipping.
