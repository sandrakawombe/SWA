package edu.lab.orderservice;

import java.util.List;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class OrderServiceApplication implements CommandLineRunner {

    private static final String ESB_URL = "http://localhost:8080/orders";

    private final RestTemplate restTemplate;

    public OrderServiceApplication(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public static void main(String[] args) {
        SpringApplication.run(OrderServiceApplication.class, args);
    }

    @Bean
    public static RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Override
    public void run(String... args) {
        List<Order> orders = List.of(
                new Order("O-1", 100.00, "domestic"),       // normal shipping
                new Order("O-2", 250.00, "domestic"),       // next day shipping
                new Order("O-3", 175.00, "domestic"),       // normal shipping (not MORE than 175)
                new Order("O-4", 175.01, "domestic"),       // next day shipping
                new Order("O-5", 80.00, "international"),   // international shipping
                new Order("O-6", 900.00, "international")   // international shipping
        );

        for (Order order : orders) {
            System.out.println("OrderService sending: " + order);
            String response = restTemplate.postForObject(ESB_URL, order, String.class);
            System.out.println("ESB response: " + response);
        }
    }
}
