package edu.lab.esb.router;

import edu.lab.esb.Order;
import org.springframework.stereotype.Component;

/** Router 1 (part b): international orders vs domestic orders. */
@Component
public class OrderTypeRouter {

    public String route(Order order) {
        String channel = "international".equalsIgnoreCase(order.getOrderType())
                ? "internationalshippingchannel"
                : "domesticshippingchannel";
        System.out.println("OrderTypeRouter: " + order.getOrderNumber() + " -> " + channel);
        return channel;
    }
}
