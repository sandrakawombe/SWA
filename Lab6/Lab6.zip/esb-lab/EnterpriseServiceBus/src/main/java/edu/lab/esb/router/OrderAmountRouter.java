package edu.lab.esb.router;

import edu.lab.esb.Order;
import org.springframework.stereotype.Component;

/** Router 2: more than 175 dollars -> next day shipping, otherwise normal shipping. */
@Component
public class OrderAmountRouter {

    public static final double NEXT_DAY_THRESHOLD = 175.0;

    public String route(Order order) {
        String channel = order.getAmount() > NEXT_DAY_THRESHOLD
                ? "nextdayshippingchannel"
                : "normalshippingchannel";
        System.out.println("OrderAmountRouter: " + order.getOrderNumber() + " -> " + channel);
        return channel;
    }
}
