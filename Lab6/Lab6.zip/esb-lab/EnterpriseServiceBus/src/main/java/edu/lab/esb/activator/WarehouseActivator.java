package edu.lab.esb.activator;

import edu.lab.esb.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class WarehouseActivator {

    @Autowired
    private RestTemplate restTemplate;

    /** Sends the order to the WarehouseService and passes it on to the shippingchannel. */
    public Order checkWarehouse(Order order) {
        restTemplate.postForObject("http://localhost:8081/orders", order, String.class);
        return order;
    }
}
