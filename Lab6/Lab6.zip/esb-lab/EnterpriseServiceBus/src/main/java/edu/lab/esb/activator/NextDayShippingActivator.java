package edu.lab.esb.activator;

import edu.lab.esb.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class NextDayShippingActivator {

    @Autowired
    private RestTemplate restTemplate;

    /** Sends the order to the next day shipping service on port 8083. */
    public void ship(Order order) {
        restTemplate.postForObject("http://localhost:8083/orders", order, String.class);
    }
}
