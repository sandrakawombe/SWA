package edu.lab.esb;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderController {

    @Autowired
    @Qualifier("warehousechannel")
    private MessageChannel warehouseChannel;

    @PostMapping("/orders")
    public ResponseEntity<String> receiveOrder(@RequestBody Order order) {
        System.out.println("ESB received: " + order);
        Message<Order> message = MessageBuilder.withPayload(order).build();
        warehouseChannel.send(message);
        return ResponseEntity.ok("Order " + order.getOrderNumber() + " processed");
    }
}
