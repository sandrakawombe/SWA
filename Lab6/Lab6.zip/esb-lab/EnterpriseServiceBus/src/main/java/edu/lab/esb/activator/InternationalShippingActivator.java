package edu.lab.esb.activator;

import edu.lab.esb.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component
public class InternationalShippingActivator {

    @Autowired
    private RestTemplate restTemplate;

    /** Sends the order to the international shipping service on port 8084. */
    public void ship(Order order) {
        restTemplate.postForObject("http://localhost:8084/orders", order, String.class);
    }
}
