package edu.lab.esb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ImportResource;
import org.springframework.web.client.RestTemplate;

/**
 * Part b (final solution) is loaded by default: integration.xml
 * To run Part a instead start with:  --esb.config=integration-part-a.xml
 */
@SpringBootApplication
@ImportResource("classpath:${esb.config:integration.xml}")
public class EsbApplication {

    public static void main(String[] args) {
        SpringApplication.run(EsbApplication.class, args);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}
