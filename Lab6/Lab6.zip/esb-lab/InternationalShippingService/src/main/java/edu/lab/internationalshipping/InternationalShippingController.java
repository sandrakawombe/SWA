package edu.lab.internationalshipping;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class InternationalShippingController {

    @PostMapping("/orders")
    public ResponseEntity<String> receiveOrder(@RequestBody Order order) {
        System.out.println("InternationalShippingService received: " + order);
        return ResponseEntity.ok("InternationalShippingService handled " + order.getOrderNumber());
    }
}
