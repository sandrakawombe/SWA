package edu.lab.normalshipping;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NormalShippingServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(NormalShippingServiceApplication.class, args);
    }
}
