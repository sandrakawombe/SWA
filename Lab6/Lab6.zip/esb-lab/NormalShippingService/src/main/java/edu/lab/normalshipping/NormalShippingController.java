package edu.lab.normalshipping;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class NormalShippingController {

    @PostMapping("/orders")
    public ResponseEntity<String> receiveOrder(@RequestBody Order order) {
        System.out.println("NormalShippingService received: " + order);
        return ResponseEntity.ok("NormalShippingService handled " + order.getOrderNumber());
    }
}
