package com.mediconnect.lab5.Shopping.repository;

import com.mediconnect.lab5.Shopping.domain.ShoppingCart;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface ShoppingCartRepository extends MongoRepository<ShoppingCart, String> {
}