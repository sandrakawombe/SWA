package com.mediconnect.lab5.Shopping.integration;

import com.mediconnect.lab5.Product.domain.Product;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;


@Component
public class ProductClient {

    private final RestTemplate restTemplate = new RestTemplate();

    @Value("${webshop.product.baseurl}")
    private String baseUrl;

    public Product getProduct(String productNumber) {
        return restTemplate.getForObject(baseUrl + "/products/" + productNumber, Product.class);
    }
}