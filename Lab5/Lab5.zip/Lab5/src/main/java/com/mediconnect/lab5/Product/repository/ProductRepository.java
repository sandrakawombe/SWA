package com.mediconnect.lab5.Product.repository;


import com.mediconnect.lab5.Product.domain.Product;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface ProductRepository extends MongoRepository<Product, String> {
}