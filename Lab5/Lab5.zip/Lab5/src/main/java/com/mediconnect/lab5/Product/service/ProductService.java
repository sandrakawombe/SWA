package com.mediconnect.lab5.Product.service;

import com.mediconnect.lab5.Product.domain.Product;
import com.mediconnect.lab5.Product.repository.ProductRepository;
import org.springframework.stereotype.Service;


@Service
public class ProductService {

    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public Product addProduct(Product product) {
        return repository.save(product);
    }

    public Product getProduct(String productNumber) {
        return repository.findById(productNumber)
                .orElseThrow(() -> new IllegalArgumentException("No product " + productNumber));
    }
}