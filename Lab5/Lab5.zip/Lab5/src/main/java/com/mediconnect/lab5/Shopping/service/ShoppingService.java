package com.mediconnect.lab5.Shopping.service;

import com.mediconnect.lab5.Product.domain.Product;
import com.mediconnect.lab5.Shopping.domain.ShoppingCart;
import com.mediconnect.lab5.Shopping.integration.ProductClient;
import com.mediconnect.lab5.Shopping.repository.ShoppingCartRepository;
import org.springframework.stereotype.Service;


@Service
public class ShoppingService {

    private final ShoppingCartRepository repository;
    private final ProductClient productClient;

    public ShoppingService(ShoppingCartRepository repository, ProductClient productClient) {
        this.repository = repository;
        this.productClient = productClient;
    }

    public ShoppingCart addToShoppingCart(String cartNumber, String productNumber, int quantity) {
        ShoppingCart cart = repository.findById(cartNumber)
                .orElse(new ShoppingCart(cartNumber));

        Product product = productClient.getProduct(productNumber);
        cart.addToCart(product.getProductNumber(), product.getName(), product.getPrice(), quantity);

        return repository.save(cart);
    }

    public ShoppingCart getShoppingCart(String cartNumber) {
        return repository.findById(cartNumber)
                .orElseThrow(() -> new IllegalArgumentException("No cart " + cartNumber));
    }
}