package com.mediconnect.lab5.Shopping.domain;

public class CartLine {

    private String productNumber;
    private String productName;
    private double unitPrice;
    private int quantity;

    public CartLine() { }

    public CartLine(String productNumber, String productName, double unitPrice, int quantity) {
        this.productNumber = productNumber;
        this.productName = productName;
        this.unitPrice = unitPrice;
        this.quantity = quantity;
    }

    public String getProductNumber() { return productNumber; }
    public void setProductNumber(String productNumber) { this.productNumber = productNumber; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double unitPrice) { this.unitPrice = unitPrice; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double lineTotal() { return unitPrice * quantity; }

    @Override
    public String toString() {
        return quantity + " x " + productName + " (" + productNumber + ") = " + lineTotal();
    }
}