package com.mediconnect.lab5.Shopping.rest;

import com.mediconnect.lab5.Shopping.domain.ShoppingCart;
import com.mediconnect.lab5.Shopping.service.ShoppingService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/shoppingcarts")
public class ShoppingCartController {

    private final ShoppingService service;

    public ShoppingCartController(ShoppingService service) {
        this.service = service;
    }

    @PostMapping("/{cartNumber}/lines")
    public ResponseEntity<ShoppingCart> addToShoppingCart(@PathVariable String cartNumber,
                                                          @RequestBody AddToCartRequest request) {
        return ResponseEntity.ok(
                service.addToShoppingCart(cartNumber, request.getProductNumber(), request.getQuantity()));
    }

    @GetMapping("/{cartNumber}")
    public ResponseEntity<ShoppingCart> getShoppingCart(@PathVariable String cartNumber) {
        return ResponseEntity.ok(service.getShoppingCart(cartNumber));
    }
}